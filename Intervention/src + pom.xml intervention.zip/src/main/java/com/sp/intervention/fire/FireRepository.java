package com.sp.intervention.fire;

import org.springframework.data.repository.CrudRepository;
public interface FireRepository extends CrudRepository<Fire, Integer> {
	
}