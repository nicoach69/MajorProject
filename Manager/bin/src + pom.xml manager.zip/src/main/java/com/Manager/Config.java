package com.Manager;

public class Config {

}
