package com.Manager.Controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.server.ResponseStatusException;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

import com.lib.VehicleModel;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lib.FireModel;
import com.fasterxml.jackson.core.type.TypeReference;

@RestController
public class ManagerCtrl {

	private String movementURL = "http://localhost:8086/Movement";
	private String interventionURL = "http://localhost:8084/Intervention";
	private String helpURL = "http://localhost:8085/Helper";
	
	private RestTemplate restTemplate;

	ManagerCtrl() {
		this.restTemplate = new RestTemplate();
	}
	@RequestMapping(method=RequestMethod.POST,value="/Fires")
	public void updateFires(@RequestBody String json_fires) throws URISyntaxException, JsonParseException, JsonMappingException, IOException {
		ArrayList<FireModel> fires = new ArrayList<FireModel>(Arrays.asList(new ObjectMapper().readValue(json_fires, FireModel[].class)));
		System.out.println(fires);
		ResponseEntity<String> result = restTemplate.postForEntity(new URI(interventionURL + "/Fires"), fires, String.class);
		
		Integer[] returnedValue = new ObjectMapper().readValue(result.getBody(), Integer[].class);
		//if(returnedValue.length != 0) {
			List<Integer> list =  new ArrayList<Integer>(Arrays.asList(returnedValue));
			restTemplate.postForEntity(new URI(helpURL + "/End"), list, String.class);

			throw new ResponseStatusException(HttpStatus.OK, "OK");
		//}
	}

	@RequestMapping(method=RequestMethod.POST,value="/Vehicles")
	public void updateVehicles(@RequestBody String json_vehicles) throws URISyntaxException, JsonParseException, JsonMappingException, IOException {
		ArrayList<VehicleModel> vehicles = new ArrayList<VehicleModel>(Arrays.asList(new ObjectMapper().readValue(json_vehicles, VehicleModel[].class)));
		System.out.println(vehicles);
		
		restTemplate.put(new URI(helpURL + "/Vehicles"), vehicles);
		restTemplate.put(new URI(movementURL + "/Vehicles"), vehicles);
	}

	@RequestMapping(method=RequestMethod.PUT,value="/Calcul")
	public void startCalcul() throws JsonParseException, JsonMappingException, IOException {
		ResponseEntity<String> result = restTemplate.getForEntity(interventionURL + "/FiresWithoutHelpers", (String.class));
		ArrayList<FireModel> fires = new ArrayList<FireModel>(Arrays.asList(new ObjectMapper().readValue(result.getBody(), FireModel[].class)));
		ResponseEntity<String> response = restTemplate.postForEntity(helpURL + "/HelpIfPossible", fires, String.class);
		System.out.println(response.getBody());
		
		@SuppressWarnings("unchecked")
		HashMap<Integer , ArrayList<Integer>> map = new ObjectMapper().readValue(response.getBody(), HashMap.class);
		System.out.println(map);
		
		response = restTemplate.postForEntity(interventionURL + "/Resolvers", map, String.class);
		@SuppressWarnings("unchecked")
		
		HashMap<Integer , FireModel> res = new ObjectMapper().readValue(response.getBody(), HashMap.class);
		restTemplate.postForEntity(movementURL + "/Vehicles", res, String.class);
	}
}